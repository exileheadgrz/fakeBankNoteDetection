from experiment import *
from torch.utils.data import DataLoader, TensorDataset
from torchvision.models import EfficientNet_V2_S_Weights

def get_features(split,mode):
    return torch.from_numpy(np.load(HERE/f'{split}-{mode}.npy'))
def fresh_head(seed):
    torch.manual_seed(seed)
    m=efficientnet_v2_s(weights=EfficientNet_V2_S_Weights.IMAGENET1K_V1)
    m.classifier[-1]=nn.Linear(m.classifier[-1].in_features,3)
    return m.classifier
def train_head(seed,mode,rows):
    head=fresh_head(seed)
    def loader(split):
        ds=TensorDataset(get_features(split,mode),torch.tensor(rows[rows.split==split].label.to_list()))
        if split=='train':
            return DataLoader(ds,batch_size=32,shuffle=True,generator=torch.Generator().manual_seed(seed))
        return DataLoader(ds,batch_size=32)
    train,val=loader('train'),loader('val')
    optimizer=torch.optim.Adam(head.parameters(),lr=0.001)
    best=float('inf')
    for epoch in range(1,31):
        head.train()
        for x,y in train:
            optimizer.zero_grad()
            loss=nn.functional.cross_entropy(head(x),y)
            loss.backward()
            optimizer.step()
        head.eval()
        with torch.no_grad(): loss=sum(nn.functional.cross_entropy(head(x),y,reduction='sum').item() for x,y in val)/len(val.dataset)
        assert np.isfinite(loss)
        if loss<best:
            best=loss
            best_epoch=epoch
            best_weights={k:v.detach().clone() for k,v in head.state_dict().items()}
        if epoch-best_epoch>=8: break
    head.load_state_dict(best_weights)
    torch.save(best_weights,HERE/f'head-{seed}-{mode}.pt')
    return head.eval(),best_epoch
def summarize(probs,labels):
    pred=probs.argmax(1)
    cm=np.zeros((3,3),int)
    np.add.at(cm,(labels,pred),1)
    return {'correct':int(cm.trace()),'correct_fake':int(cm[0,0]),'real_as_fake':int(cm[1,0]),'other_correct':int(cm[2,2]),'fake_as_real':int(cm[0,1]),'confusion_matrix':json.dumps(cm.tolist())}
def main():
    rows=roster()
    archived=json.loads((RUN/'comparison.json').read_text())['runs']
    archive_ocr=pd.read_csv(ROOT/'runs/issuer_review_v1/per_photo.csv',keep_default_na=False).set_index('file')
    summary=[]; per=[]; queues=[]
    def record(arch,training,mode,seed,split,probs,epoch=None):
        r=rows[rows.split==split].copy()
        r['file']=r.file.map(lambda f:Path(f).name)
        probs=probs.detach().numpy()
        assert np.isfinite(probs).all()
        preds=probs.argmax(1)
        prefix=dict(model=arch,training=training,input=mode,seed=seed)
        if split=='test':
            if training=='archived' and mode=='square':
                previous=next(run for run in archived if run['architecture']==arch and run['seed']==seed)
                old={Path(x['path']).name:x for x in previous['test_predictions']}
                assert list(preds)==[old[f]['predicted_label'] for f in r.file]
                assert np.max(np.abs(probs-np.array([old[f]['probabilities'] for f in r.file])))<0.002
            summary.append(dict(**prefix,best_epoch=epoch,**summarize(probs,r.label.to_numpy())))
        for row,p,pred in zip(r.itertuples(),probs,preds):
            per.append(dict(**prefix,split=split,file=row.file,label=row.label,prediction=int(pred),p_fake=p[0],p_real=p[1],p_other=p[2]))
        if split=='review':
            r['pred']=preds
            r['p_real']=probs[:,1]
            r['mismatch']=[archive_ocr.loc[f,'Issuer']=='different' for f in r.file]
            if training=='archived' and mode=='square' and seed==42:
                assert np.max(np.abs(r.p_real.to_numpy()-archive_ocr.loc[r.file,'P(Real)'].to_numpy()))<.002
            real=r[r.pred==1]
            a=real.sort_values(['p_real','file']).head(5)
            b=real.sort_values(['mismatch','p_real','file'],ascending=[False,True,True]).head(5)
            queues.append(dict(**prefix,eligible=len(real),fake_called_real=int((real.label==0).sum()),direct_fake_alerts=int(((real.label==0)&real.mismatch).sum()),direct_real_alerts=int(((real.label==1)&real.mismatch).sum()),n_review=len(b),low_confidence_fake_found=int((a.label==0).sum()),issuer_first_fake_found=int((b.label==0).sum()),low_queue='|'.join(a.file),issuer_queue='|'.join(b.file)))
    for arch in ('efficientnet_v2_s','resnet18'):
        layer='classifier.1' if arch==MODEL else 'fc'
        modes=('square','rectangle','native_rgb','square_bgr_norm','square_rgb_unit','square_rgb255','raw') if arch==MODEL else ('square','raw')
        for seed in SEEDS:
            sd=checkpoint(arch,seed)
            for mode in modes:
                for split in (('test','review') if arch==MODEL and mode in ('square','rectangle','raw') and seed==42 else ('test',)):
                    f=get_features(split,mode) if arch==MODEL else torch.from_numpy(np.load(HERE/f'resnet-{mode}.npy'))
                    probs=nn.functional.linear(f,sd[layer+'.weight'],sd[layer+'.bias']).softmax(1)
                    record(arch,'archived',mode,seed,split,probs)
    for mode in ('square','raw'):
        for seed in SEEDS:
            head,epoch=train_head(seed,mode,rows)
            with torch.no_grad():
                for split in (('test','review') if seed==42 else ('test',)):
                    record(MODEL,'refit_no_aug',mode,seed,split,head(get_features(split,mode)).softmax(1),epoch)
    sums=pd.DataFrame(summary)
    sums.to_csv(HERE/'test_metrics.csv',index=False)
    pd.DataFrame(per).to_csv(HERE/'predictions.csv',index=False)
    pd.DataFrame(queues).to_csv(HERE/'review_budget.csv',index=False)
    print(sums.groupby(['model','training','input'])[['correct','correct_fake','real_as_fake']].mean())
    print(pd.DataFrame(queues).drop(columns=['low_queue','issuer_queue']).to_string(index=False))
if __name__=='__main__':main()
