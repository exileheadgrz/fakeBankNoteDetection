from analyze import *
import random
def main():
    seed=42
    rows=roster()
    base=efficientnet_v2_s(num_classes=3).eval()
    base.load_state_dict(checkpoint(MODEL,42))
    base.requires_grad_(False)
    head=fresh_head(seed)
    rng=random.Random(seed)
    opt=torch.optim.Adam(head.parameters(),lr=.001)
    train=rows.query("split=='train'").reset_index(drop=True)
    loader=DataLoader(range(len(train)),batch_size=32,shuffle=True,generator=torch.Generator().manual_seed(seed))
    valrows=rows.query("split=='val'")
    val=DataLoader(TensorDataset(get_features('val','square'),torch.tensor(valrows.label.tolist())),batch_size=32)
    # LUT implements the notebook's uint8 clipped linear transforms pointwise.
    levels=np.arange(256,dtype=np.float32)
    best=float('inf')
    for epoch in range(1,31):
        head.train()
        for ids in loader:
            ys=torch.tensor(train.iloc[ids.tolist()].label.tolist())
            images=[]
            for idx in ids.tolist():
                bgr=read(train.iloc[idx].file)
                bright=rng.uniform(.9,1.1)
                bgr=cv2.LUT(bgr,(levels*bright).clip(0,255).astype(np.uint8))
                center=int(cv2.mean(cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY))[0]+.5)
                contrast=rng.uniform(.9,1.1)
                bgr=cv2.LUT(bgr,(center+(levels-center)*contrast).clip(0,255).astype(np.uint8))
                images.append(prepare(bgr,'square'))
            with torch.no_grad():
                f=torch.cat([features(base,t) for t in torch.cat(images).split(8)])
            opt.zero_grad()
            nn.functional.cross_entropy(head(f),ys).backward()
            opt.step()
        head.eval()
        with torch.no_grad():
            loss=sum(nn.functional.cross_entropy(head(f),y,reduction='sum').item() for f,y in val)/len(val.dataset)
        if loss<best:
            best=loss;best_epoch=epoch;best_sd={k:v.clone() for k,v in head.state_dict().items()}
        if epoch%5==0: print(epoch,loss,flush=True)
        if epoch-best_epoch>=8:break
    head.load_state_dict(best_sd)
    with torch.no_grad():
        probs=head(get_features('test','square')).softmax(1).numpy()
    result=dict(seed=seed,best_epoch=best_epoch,**summarize(probs,rows.query("split=='test'").label.to_numpy()))
    (HERE/'augmentation.json').write_text(json.dumps(result))
    print(result,flush=True)
if __name__=='__main__':main()
