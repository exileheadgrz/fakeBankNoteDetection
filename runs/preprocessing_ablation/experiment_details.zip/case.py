from experiment import *
from pytorch_grad_cam import GradCAM, ScoreCAM
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
import time
import matplotlib.pyplot as plt

def blocks_native(shape,valid_shape,geometry):
    # Keep the physical block layout comparable to the unpadded part of the archived 224 grid.
    h,w=shape
    H,W=valid_shape
    l,t=geometry
    ys=(np.arange(h)+.5)*H/h+t
    xs=(np.arange(w)+.5)*W/w+l
    ids=((ys//16).astype(int)[:,None]*14 + (xs//16).astype(int)[None,:]).ravel()
    order=ids.argsort(kind='stable')
    return np.split(order,np.flatnonzero(np.diff(ids[order]))+1)

def main():
    ns={}
    n=json.loads(Path('moneyDetectionFlassfier.ipynb').read_text())
    for name in ('def make_blocks','def edit_curves','def score_batches'):
        for c in n['cells']:
            s=''.join(c['source'])
            if c['cell_type']=='code' and name in s:
                ns.update(torch=torch,pd=pd,np=np,hashlib=hashlib)
                exec(s,ns)
                break
    file=DATA/'test/fake money'/CASE
    bgr=read(file)
    # From Apple Vision on the original image, using the notebook's round-to-pixel rule.
    l,t,r,b=218,103,778,183
    blur=bgr.copy()
    blur[t:b,l:r]=cv2.GaussianBlur(blur[t:b,l:r],(0,0),sigmaX=8)
    model=efficientnet_v2_s(num_classes=3).eval()
    model.load_state_dict(checkpoint(MODEL,42))
    model.requires_grad_(False)
    g=ns['score_batches']
    rows=[]
    case_scores=[]
    fraction=np.linspace(0,1,11)
    fig,axes=plt.subplots(2,3,figsize=(10,4.9))
    for row,mode in enumerate(('square','raw','opencv','rectangle')):
        x=prepare(bgr,mode)
        base=g(model,x,1)
        edited=g(model,prepare(blur,mode),1)
        vals=list(base['probabilities'][0])
        case_scores.append(dict(input=mode,width=x.shape[-1],height=x.shape[-2],p_fake=vals[0],p_real=vals[1],p_other=vals[2],p_fake_blurred=edited['probabilities'][0][0],blur_delta_pp=(edited['probabilities'][0][0]-vals[0])*100,fake_logit=base['logits'][0][0],real_logit=base['logits'][0][1]))
        if mode not in ('square','raw'):continue
        h,w=bgr.shape[:2]
        H,W=round(224*h/max(h,w)),round(224*w/max(h,w))
        t0,l0=(224-H)//2,(224-W)//2
        valid=np.ones(x.shape[-2:],bool)
        if mode=='square':
            valid[:]=False;valid[t0:t0+H,l0:l0+W]=True
            blocks=ns['make_blocks'](valid,16)
            fill=torch.zeros_like(x)
        else:
            blocks=blocks_native((h,w),(H,W),(l0,t0))
            fill=torch.tensor([.406,.456,.485])[None,:,None,None].mul(255).expand_as(x).clone()
        assert sum(map(len,blocks))==valid.sum()
        ax=axes[row,0]
        ax.imshow(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB))
        ax.set_title(f'{mode}: P(Fake) = {vals[0]:.1%}')
        ax.axis('off')
        ref=g(model,fill,1)
        orders={'random':ns['random_pixels'](blocks,hashlib.sha256(file.read_bytes()).hexdigest(),0,42)}
        for col,(name,cam_type) in enumerate([('Grad-CAM',GradCAM),('Score-CAM',ScoreCAM)],1):
            with torch.set_grad_enabled(name=='Grad-CAM'),cam_type(model=model,target_layers=[model.features[3]]) as cam:
                cam.batch_size=2 if mode=='raw' else 16
                hm=cam(x.detach().requires_grad_(name=='Grad-CAM'),targets=[ClassifierOutputTarget(0)])[0]
            assert np.isfinite(hm).all()
            visible=hm[t0:t0+H,l0:l0+W] if mode=='square' else hm
            axes[row,col].imshow(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB))
            axes[row,col].imshow(cv2.resize(visible,(w,h)),cmap='turbo',vmin=0,vmax=1,alpha=.42)
            axes[row,col].set_title(name + (' (flat)' if np.ptp(hm[valid]) < 1e-7 else ''))
            axes[row,col].axis('off')
            if np.ptp(hm[valid])>=1e-7:
                orders[name]=ns['ranked_pixels'](hm,blocks)
            else:
                rows.append(dict(input=mode,method=name,deletion_auc=None,insertion_auc=None,status='flat'))
        for method,order in orders.items():
            curves=ns['edit_curves'](model,x,fill,order,fraction,base,ref,0,2)
            d,i=ns['curve_areas'](curves)
            rows.append(dict(input=mode,method=method,deletion_auc=d,insertion_auc=i,status='ok'))
    fig.tight_layout()
    fig.savefig(HERE/'case_cam.png',dpi=155)
    pd.DataFrame(case_scores).to_csv(HERE/'case_scores.csv',index=False)
    pd.DataFrame(rows).to_csv(HERE/'case_cam.csv',index=False)
    print(pd.DataFrame(case_scores).to_string(index=False))
    print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__':main()
