from experiment import *
def main():
 torch.set_num_threads(2)
 model=efficientnet_v2_s(num_classes=3).eval()
 model.load_state_dict(checkpoint(MODEL,42))
 test=roster().query("split=='test'")
 modes=('square_bgr_norm','square_rgb_unit','square_rgb255')
 vectors={m:[] for m in modes}
 with torch.inference_mode():
  for f in test.file:
   bgr=read(f)
   h,w=bgr.shape[:2]
   H,W=round(224*h/max(w,h)),round(224*w/max(w,h))
   l,t=(224-W)//2,(224-H)//2
   a=TF.to_tensor(TF.resize(TF.to_pil_image(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)),[H,W]))
   patches=(TF.normalize(a[[2,1,0]],[.485,.456,.406],[.229,.224,.225]),a,a*255)
   squares=torch.stack([TF.pad(v,[l,t,224-W-l,224-H-t]) for v in patches])
   out=features(model,squares)
   for i,m in enumerate(modes):vectors[m].append(out[i].numpy().copy())
  for m,v in vectors.items():np.save(HERE/f'test-{m}.npy',np.stack(v))
if __name__=='__main__':main()
