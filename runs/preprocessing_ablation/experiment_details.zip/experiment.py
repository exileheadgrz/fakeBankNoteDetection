import argparse
import hashlib
import json
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import torch
from torch import nn
from torchvision.models import efficientnet_v2_s
from torchvision.transforms import functional as TF

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
DATA = ROOT / 'classification_images'
RUN = ROOT / 'runs/course_models_archive_v3'
CLASSES = ['fake money','OR money','not a banknote']
SEEDS = (42, 43, 44)
CASE = '100_4b6f91bfcd036823.png'
MODEL = 'efficientnet_v2_s'
torch.set_num_threads(3)
cv2.setNumThreads(1)

def checkpoint(arch, seed):
    rel = Path('runs/course_models_archive_v3') / arch / f'seed_{seed}/best.pt'
    path = ROOT / rel
    if not path.is_file():
        path = ROOT.parent / 'Fake_Money_Detection' / rel
    return torch.load(path, map_location='cpu', weights_only=True)['model_state_dict']

def read(path):
    x = cv2.imread(str(path),cv2.IMREAD_COLOR | cv2.IMREAD_IGNORE_ORIENTATION)
    if x is None:
        stream=cv2.VideoCapture(str(path),cv2.CAP_FFMPEG)
        ok,x=stream.read()
        stream.release()
        assert ok, path
    return x

def prepare(bgr, mode):
    if mode=='raw':
        # Casting and HWC -> CHW are required by PyTorch; keep native BGR values and dimensions.
        return torch.from_numpy(bgr).permute(2,0,1).float().unsqueeze(0).contiguous()
    rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
    h,w=rgb.shape[:2]
    s=224/max(h,w)
    H,W=max(1,round(h*s)),max(1,round(w*s))
    if mode == 'opencv':
        small = cv2.resize(rgb,(W,H),interpolation=cv2.INTER_LINEAR)
    else:
        small = TF.resize(TF.to_pil_image(rgb),[H,W])
    content=TF.normalize(TF.to_tensor(small),[.485,.456,.406],[.229,.224,.225])
    if mode == 'rectangle':
        return content.unsqueeze(0).contiguous()
    top,left=(224-H)//2,(224-W)//2
    return TF.pad(content,[left,top,224-W-left,224-H-top]).unsqueeze(0).contiguous()

def features(model, x, split_at=4, stride=8, threshold=1_500_000):
    h,w=x.shape[2:]
    if h*w<=threshold:
        y=model.features(x)
    else:
        # The first four stages are strictly local (no SE or global pooling).
        # Use a stride-aligned halo larger than their receptive field. Assemble the whole
        # feature map before any SE block or global pooling, preserving the model's context.
        tile,halo=768,64
        out=None
        for top in range(0,h,tile):
            for left in range(0,w,tile):
                bottom,right=min(h,top+tile),min(w,left+tile)
                t,l=max(0,top-halo),max(0,left-halo)
                patch=x[:,:,t:min(h,bottom+halo),l:min(w,right+halo)].contiguous()
                v=model.features[:split_at](patch)
                if out is None:
                    out=v.new_empty(1,v.shape[1],(h+stride-1)//stride,(w+stride-1)//stride)
                a,b=top//stride,left//stride
                c,d=(bottom+stride-1)//stride,(right+stride-1)//stride
                it,il=(top-t)//stride,(left-l)//stride
                out[:,:,a:c,b:d]=v[:,:,it:it+c-a,il:il+d-b]
        y=model.features[split_at:](out)
    return model.avgpool(y).flatten(1)

def roster():
    rows=[]
    for split in ('test','review','val','train'):
        if split=='review':
            manifest=json.loads((ROOT/'issuer_review_images/manifest.json').read_text())
            for r in manifest['samples']:
                rows.append((split,str(Path('issuer_review_images')/r['file']),int(r['folder_label']=='real')))
        else:
            for label,group in enumerate(CLASSES):
                for p in sorted((DATA/split/group).iterdir()):
                    if p.suffix.lower() in {'.jpg','.jpeg','.png','.avif'}:
                        rows.append((split,str(p.relative_to(ROOT)),label))
    return pd.DataFrame(rows,columns=['split','file','label'])

def extract():
    rows=roster()
    rows.to_csv(HERE/'roster.csv',index=False)
    model=efficientnet_v2_s(num_classes=3).eval()
    model.load_state_dict(checkpoint(MODEL,42))
    # Check unchanged learned features for every head and for the original pretrained backbone.
    original=torch.load(Path(torch.hub.get_dir())/'checkpoints/efficientnet_v2_s-dd5fe13b.pth',map_location='cpu',weights_only=True)
    for state in [original,checkpoint(MODEL,43),checkpoint(MODEL,44)]:
        assert all(torch.equal(param,state[name]) for name,param in model.state_dict().items() if name.startswith('features.'))
    del original,state
    with torch.inference_mode():
        probe=prepare(read(DATA/'test/fake money'/CASE),'raw')
        f=features(model,probe)
        torch.testing.assert_close(features(model,probe,threshold=1),f,rtol=3e-4,atol=3e-4)
        for split in ('test','review','val','train'):
            subset=rows[rows.split==split]
            for mode in (('square','rectangle','raw') if split in ('test','review') else ('raw',)):
                out=HERE/f'{split}-{mode}.npy'
                if out.exists():continue
                vals=[]
                for i,r in enumerate(subset.itertuples(),1):
                    x=prepare(read(ROOT/r.file),mode)
                    v=features(model,x)
                    assert torch.isfinite(v).all(),r.file
                    vals.append(v.numpy().copy())
                    if i%20==0: print(split,mode,i,'/',len(subset),flush=True)
                np.save(out,np.concatenate(vals))
                print('done',split,mode,flush=True)

if __name__=='__main__': extract()
