from experiment import *
from torchvision.models import resnet18
import timm

def main():
    torch.set_num_threads(2)
    rows=roster()
    r=rows[rows.split=='test']
    eff=efficientnet_v2_s(num_classes=3).eval()
    eff.load_state_dict(checkpoint(MODEL,42))
    with torch.inference_mode():
        for split in ('val','train'):
            subset=rows[rows.split==split]
            np.save(HERE/f'{split}-square.npy',np.concatenate([features(eff,prepare(read(ROOT/f),'square')).numpy() for f in subset.file]))
        # Keep original dimensions but restore the pretrained model's expected colour channel order and scale.
        mean=torch.tensor([.485,.456,.406])[None,:,None,None]
        std=torch.tensor([.229,.224,.225])[None,:,None,None]
        native=[]
        for f in r.file:
            bgr=prepare(read(ROOT/f),'raw')
            rgb=(bgr[:,[2,1,0]]/255-mean)/std
            native.append(features(eff,rgb).numpy())
        np.save(HERE/'test-native_rgb.npy',np.concatenate(native))
        rn=resnet18(num_classes=3).eval()
        rn.load_state_dict(checkpoint('resnet18',42))
        class FeatureModel(nn.Module):
            def __init__(self,rn):
                super().__init__()
                self.features=nn.Sequential(nn.Sequential(rn.conv1,rn.bn1,rn.relu,rn.maxpool),rn.layer1,rn.layer2,rn.layer3,rn.layer4)
                self.avgpool=rn.avgpool
        backbone=FeatureModel(rn).eval()
        for seed in (43,44):
            sd=checkpoint('resnet18',seed)
            assert all(torch.equal(v,sd[k]) for k,v in rn.state_dict().items() if not k.startswith('fc.'))
        for mode in ('square','raw'):
            vectors=[features(backbone,prepare(read(ROOT/f),mode),split_at=3).numpy() for f in r.file]
            np.save(HERE/f'resnet-{mode}.npy',np.concatenate(vectors))
            print('ResNet test',mode,flush=True)
        text=read(DATA/'test/fake money/2000_64e4be101b99f1cb.png')
        inp=prepare(text,'raw')
        ns={}
        notebook=json.loads((ROOT/'moneyDetectionFlassfier.ipynb').read_text())
        for i in (1,2,20,22): exec(''.join(notebook['cells'][i]['source']),ns)
        checks={}
        for arch in ('cnn','dinov3_vits16'):
            m=ns['build_model'](arch).eval()
            m.load_state_dict(checkpoint(arch,42))
            try:
                out=m(inp)
                checks[arch]=f'succeeded: {out.shape}'
            except (RuntimeError,AssertionError) as e:
                checks[arch]=str(e)
        print('Native input compatibility',inp.shape,checks)
        (HERE/'compatibility.json').write_text(json.dumps(checks,indent=2))
if __name__=='__main__':main()
