from experiment import *
from torchvision.models import resnet18
def main():
 torch.set_num_threads(2)
 rows=roster()
 r=rows.query("split=='test'")
 candidates=[]
 for f in r.file:
  from PIL import Image
  with Image.open(f) as im:
   if min(im.size)>768 and im.width*im.height<2_400_000: candidates.append(f)
 f=min(candidates)
 x=prepare(read(f),'raw')
 eff=efficientnet_v2_s(num_classes=3).eval()
 eff.load_state_dict(checkpoint(MODEL,42))
 res=resnet18(num_classes=3).eval()
 res.load_state_dict(checkpoint('resnet18',42))
 class Encoder(nn.Module):
  def __init__(self,model):
   super().__init__()
   self.features=nn.Sequential(nn.Sequential(model.conv1,model.bn1,model.relu,model.maxpool),model.layer1,model.layer2,model.layer3,model.layer4)
   self.avgpool=model.avgpool
 wrapped=Encoder(res).eval()
 with torch.inference_mode():
  for m,fn,head,sp in [(eff,eff,eff.classifier,4),(res,wrapped,res.fc,3)]:
   direct=m(x)
   tiled=head(features(fn,x,split_at=sp,threshold=1))
   torch.testing.assert_close(direct,tiled,rtol=.0001,atol=.03)
   print(type(m).__name__,x.shape,'maximum logit difference',abs(tiled-direct).max().item())
 p=pd.read_csv(HERE/'predictions.csv')
 for key,group in p.groupby(['model','training','input','seed','split']):
  assert len(group)==(53 if key[-1]=='test' else 48)
  assert group.file.is_unique
  assert set(group.file)==set(rows[rows.split==key[-1]].file.map(lambda f:Path(f).name))
  if key[-1]=='test':
   assert group.label.value_counts().to_dict()=={1:25,0:24,2:4}
 print('case results:',pd.read_csv(HERE/'case_scores.csv')[['input','p_fake','p_real','blur_delta_pp']].to_string(index=False))
if __name__=='__main__':main()
